# Jott_Interpreter
Semester project for PLC

Group: 

Team members:
    Raymond Healy, Antony Lin, Jimmy Cao, Tyler Whitehurst

## To compile:
- `make` will compile to the `./compiled` directory
- `make clean` will clean compiled files

## To run
- `make` the src
- `cd ./compiled`
- `java Jott $(PROGRAM_NAME).j`