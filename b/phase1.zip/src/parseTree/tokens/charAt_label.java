package src.parseTree.tokens;

public class charAt_label extends token {
    public charAt_label(int lineNumber) {
        super(lineNumber);
    }

    public String toString() {
        return "charAt";
    }
}
