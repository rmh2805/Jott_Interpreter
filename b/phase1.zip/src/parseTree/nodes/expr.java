package src.parseTree.nodes;

public abstract class expr<T> extends stmt<T> {}
