package src.parseTree.categories;

public interface int_val {
}
