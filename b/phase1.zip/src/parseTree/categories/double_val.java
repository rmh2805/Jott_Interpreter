package src.parseTree.categories;

public interface double_val {
}
