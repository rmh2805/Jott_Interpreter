package src.parseTree.categories;

public interface Type {
}
