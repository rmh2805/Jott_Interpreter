package src.errorHandling.types;

public class Runtime extends abstract_error {
    public Runtime(String remedy) {
        super(remedy, "Runtime");
    }
}
