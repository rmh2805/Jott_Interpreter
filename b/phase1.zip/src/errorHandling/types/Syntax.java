package src.errorHandling.types;

public class Syntax extends abstract_error {
    public Syntax(String remedy) {
        super(remedy, "Syntax");
    }
}
