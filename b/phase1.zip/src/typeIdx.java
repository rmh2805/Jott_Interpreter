package src;

public enum typeIdx {
    k_Integer, k_Double, k_String
}
